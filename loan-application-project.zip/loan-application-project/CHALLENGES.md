# Problems I Faced While Building This (and how I solved them)

Being honest about real problems — even small ones — makes this project far more
credible in an interview than pretending everything went perfectly.

## 1. Estimating story points for the credit-check story
**Problem:** I initially estimated "Automated credit check" as 3 points, same as the
simpler stories, but it involved calling an external service, handling multiple
response scenarios (approved, rejected, needs manual review), and error handling.
**What I did:** Re-estimated it as 8 points after breaking down what "done" really
meant, and noted in the retrospective that it should be split into two stories next
time — this taught me why breaking down large stories matters.

## 2. Writing acceptance criteria that only covered the happy path
**Problem:** My first draft of acceptance criteria only described what happens when
everything goes right (valid documents, good credit score).
**What I did:** Went back and added a negative/error case — e.g., what happens if the
credit-check service times out, or an application ID doesn't exist (see Postman
request #3, "Application Not Found"). This is a mistake beginners often make, and
fixing it made the requirements far more complete.

## 3. Choosing a real API to practice Postman with
**Problem:** The real bank credit-check API obviously doesn't exist for a practice
project, so I couldn't test against it.
**What I did:** Used a public test API (reqres.in) to simulate the request/response
shape instead — this is actually a realistic BA/PO skill, since in real projects you
often build and test against a "mock" API before the real backend is ready.

## 4. Structuring the draw.io diagram clearly with 3 different actors
**Problem:** My first version of the process diagram put every step in one long line,
which didn't make it clear who (customer, bank system, or credit-check service) was
responsible for each step.
**What I did:** Rebuilt it as a swimlane diagram, with one lane per actor — this is a
standard technique or diagramming this way and made the diagram far easier to explain
to a non-technical stakeholder.

## 5. Deciding what belonged in Confluence vs Jira
**Problem:** Early on I put too much detail directly into Jira story descriptions,
duplicating what should have lived in the BRD.
**What I did:** Moved the "why" (business goal, scope, stakeholders) into the
Confluence BRD, and kept Jira stories focused only on the "what" (acceptance criteria
for one specific piece of work) — this mirrors how real BA/PO teams split
documentation.

## What I'd do differently next time
- Involve a "mock stakeholder" earlier (even just asking a friend to play the client
  role) to pressure-test whether my requirements were actually clear.
- Estimate story points in a quick planning-poker style pass rather than gut-feel, to
  practice that specific Scrum technique.
