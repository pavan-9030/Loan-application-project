# Sprint Plan — Digital Loan Application

## Sprint 1 — "Get the application in the door"
**Sprint Goal:** Customers can submit a complete loan application online, with documents,
without any manual/branch involvement.

**Stories committed:** Start application, Upload documents, Automated credit check
**Total story points:** 16
**Duration:** 2 weeks

**Sprint Review notes (simulated):**
- Start application and Upload documents were demoed and accepted by the "Product
  Owner" (me, in the client's shoes).
- Automated credit check was 80% done — the mock credit-check API integration took
  longer than estimated (see CHALLENGES.md).

**Retrospective notes:**
- Went well: breaking the Epic into small stories made estimation easier.
- To improve: the credit-check story should have been split further — "call the credit
  API" and "map credit score to status" are really two separate pieces of work.

## Sprint 2 — "Keep the customer informed"
**Sprint Goal:** Customers always know their application status without contacting the
bank, and the Product Owner can see where applications are stuck.

**Stories committed:** View real-time status, Status change notifications, Application
funnel report
**Total story points:** 11
**Duration:** 2 weeks

## Velocity tracking
| Sprint | Committed points | Completed points |
|---|---|---|
| Sprint 1 | 16 | 13 (Automated credit check partially carried over) |
| Sprint 2 | 11 | 11 (planned) |

Average velocity after 2 sprints: **~12 points/sprint** — used to plan future sprints
realistically instead of guessing.
