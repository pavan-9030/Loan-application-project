# Business Requirement Document — Digital Loan Application

**Page owner:** Business Analyst / Product Owner
**Status:** Approved for development
**Linked Jira Epic:** Digital Loan Application

## 1. Business Problem
Customers currently must visit a branch to apply for a personal loan, which takes an
average of 3 business days end to end. This creates friction, loses customers to
competitors with faster digital options, and increases branch workload.

## 2. Goal
Allow a customer to apply for, upload documents for, and track a personal loan
application entirely online, reducing total processing time and branch dependency.

## 3. Scope
**In scope:**
- Online application form (amount, tenure, purpose)
- Document upload (ID + income proof)
- Automated credit check integration
- Real-time status tracking for the customer
- Email/SMS notifications on status change

**Out of scope (this phase):**
- Business/corporate loans (retail personal loans only)
- Loan disbursement automation (handled by an existing separate system)
- Multi-currency loans

## 4. Stakeholders
- Retail Banking Product Manager (business sponsor)
- Development team (Scrum team)
- Compliance team (KYC/AML sign-off required before go-live)
- Customer support (needs visibility into application status for support calls)

## 5. Key Business Rules
- A customer must complete KYC verification before submitting a loan application.
- Applications above a certain loan amount are automatically flagged for manual
  underwriting review, regardless of credit score.
- Customers can only have one active application in progress at a time.

## 6. Success Metrics
- Reduce average application-to-decision time from 3 days to under 1 day.
- 90% of applications require no manual intervention (straight-through processing).
- Reduce related support calls ("what's my application status") by 50%.

## 7. Linked Artifacts
- Jira Epic and Stories: see `/jira/epics_stories.csv`
- Process flow diagram: see `/diagrams/loan_process_flow.drawio`
- API contract (draft): see `/postman/loan_status_api.postman_collection.json`
